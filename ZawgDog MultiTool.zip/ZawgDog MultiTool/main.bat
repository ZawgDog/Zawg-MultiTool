@echo off
title Zawg MultiTool - by ZawgDog lowk skidded from ebola man
chcp 65001 >nul
cd files

call :banner

:menu
cls
call :banner

for /f %%A in ('"prompt $H &echo on &for %%B in (1) do rem"') do set BS=%%A
echo.
echo.
echo   		 [38;2;255;0;0m╔═(1) VirtualBox📦
echo  		 [38;2;255;51;0m║
echo  		 [38;2;255;102;0m╚╦(2) Wireshark
echo  		 [38;2;255;153;0m ║
set /p input=.%BS%   		  [38;2;255;204;0m╚═══^>

if /I "%input%"=="1" start VirtualBox.lnk
if /I "%input%"=="2" start Wireshark.lnk
goto menu


:banner
echo.
echo.
echo 		🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭
echo			[38;2;0;255;0m🌭███████╗ █████╗ ██╗    ██╗ ██████╗     ███╗   ███╗██╗   ██╗██╗  ████████╗██╗🌭[0m
echo			[38;2;64;255;0m🌭╚══███╔╝██╔══██╗██║    ██║██╔════╝     ████╗ ████║██║   ██║██║  ╚══██╔══╝██║🌭[0m
echo			[38;2;128;255;0m🌭  ███╔╝ ███████║██║ █╗ ██║██║  ███╗    ██╔████╔██║██║   ██║██║     ██║   ██║🌭[0m
echo			[38;2;192;255;0m🌭 ███╔╝  ██╔══██║██║███╗██║██║   ██║    ██║╚██╔╝██║██║   ██║██║     ██║   ██║🌭[0m
echo			[38;2;255;255;0m🌭███████╗██║  ██║╚███╔███╔╝╚██████╔╝    ██║ ╚═╝ ██║╚██████╔╝███████╗██║   ██║🌭[0m
echo			[38;2;255;255;0m🌭╚══════╝╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝     ╚═╝     ╚═╝ ╚═════╝ ╚══════╝╚═╝   ╚═╝🌭[0m
echo 		🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭🌭
echo					i skidded the code but made the logo n stuff 
echo 				so lmk what u want on this and ill put it 
echo.
goto :eof
⠀⠀⠀⠀⠀⠀⠀